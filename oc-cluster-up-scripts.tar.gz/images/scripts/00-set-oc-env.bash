export INSTALLPATH=$1
if [ ! -d ${INSTALLPATH} ]
then
	mkdir ${INSTALLPATH}
fi;
